# Student Management System

A web app built with **Python Flask + SQLite**. No database setup is needed: `students.db` is created automatically on first run.

## Features
- Admin login (password stored hashed)
- Dashboard with totals, today's attendance and students per course
- Students: add, edit, delete, search, filter by course, view profile, export CSV
- Courses: add and delete
- Attendance: mark per course and date (re-open a date to edit it)
- Marks: record scores, automatic grades, per-student average

## Run in VS Code
1. Install Python 3.9+ and open this folder in VS Code (File > Open Folder).
2. Open a terminal (Ctrl + `) and create a virtual environment:
   - Windows: `python -m venv venv` then `venv\Scripts\activate`
   - Mac/Linux: `python3 -m venv venv` then `source venv/bin/activate`
3. Install dependencies: `pip install -r requirements.txt`
4. Start the app: `python app.py` (or press F5)
5. Open http://127.0.0.1:5000

**Login:** `admin` / `admin123`

To reset the data, stop the app and delete `students.db`.

## Structure
```
student_management/
  app.py            routes, database, logic
  requirements.txt
  static/style.css
  templates/        HTML pages (Jinja2)
  .vscode/launch.json
```
