"""Student Management System - Flask + SQLite mini project."""
import csv
import io
import os
import sqlite3
from datetime import date
from functools import wraps

from flask import (Flask, Response, flash, g, redirect, render_template,
                   request, session, url_for)
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATABASE = os.path.join(BASE_DIR, "students.db")

app = Flask(__name__)
app.config["SECRET_KEY"] = "change-this-secret-key"

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS courses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    credits INTEGER NOT NULL DEFAULT 3
);
CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    roll_no TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    dob TEXT,
    gender TEXT,
    address TEXT,
    course_id INTEGER REFERENCES courses(id) ON DELETE SET NULL,
    joined_on TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    day TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('present', 'absent')),
    UNIQUE (student_id, day)
);
CREATE TABLE IF NOT EXISTS marks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    subject TEXT NOT NULL,
    exam TEXT NOT NULL,
    score REAL NOT NULL,
    max_score REAL NOT NULL DEFAULT 100
);
"""


# ---------------------------------------------------------------- database
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DATABASE)
    db.executescript(SCHEMA)
    if not db.execute("SELECT 1 FROM users").fetchone():
        db.execute("INSERT INTO users (username, password_hash) VALUES (?, ?)",
                   ("admin", generate_password_hash("admin123")))
        courses = [("CS101", "Computer Science", 4), ("EE201", "Electronics", 4),
                   ("ME301", "Mechanical Engineering", 3), ("BA110", "Business Administration", 3)]
        db.executemany("INSERT INTO courses (code, name, credits) VALUES (?, ?, ?)", courses)
        today = date.today().isoformat()
        sample = [
            ("S001", "Aarav Kumar", "aarav@example.com", "9876500001", "2005-03-14", "Male", "Chennai", 1),
            ("S002", "Meera Iyer", "meera@example.com", "9876500002", "2004-11-02", "Female", "Coimbatore", 1),
            ("S003", "Rohan Das", "rohan@example.com", "9876500003", "2005-07-21", "Male", "Madurai", 2),
            ("S004", "Priya Nair", "priya@example.com", "9876500004", "2004-01-30", "Female", "Kochi", 3),
            ("S005", "Karthik Raj", "karthik@example.com", "9876500005", "2005-09-09", "Male", "Trichy", 4),
        ]
        db.executemany(
            "INSERT INTO students (roll_no, name, email, phone, dob, gender, address, course_id, joined_on) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", [s + (today,) for s in sample])
    db.commit()
    db.close()


# ----------------------------------------------------------------- helpers
def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


@app.template_filter("grade")
def grade(pct):
    for limit, letter in ((90, "A+"), (80, "A"), (70, "B"), (60, "C"), (50, "D")):
        if pct >= limit:
            return letter
    return "F"


def student_form_data():
    f = request.form
    return {
        "roll_no": f.get("roll_no", "").strip(),
        "name": f.get("name", "").strip(),
        "email": f.get("email", "").strip(),
        "phone": f.get("phone", "").strip(),
        "dob": f.get("dob", "").strip(),
        "gender": f.get("gender", "").strip(),
        "address": f.get("address", "").strip(),
        "course_id": f.get("course_id") or None,
    }


def attendance_summary(db, student_id):
    row = db.execute(
        "SELECT COUNT(*) AS total, COALESCE(SUM(status = 'present'), 0) AS present "
        "FROM attendance WHERE student_id = ?", (student_id,)).fetchone()
    pct = round(row["present"] * 100 / row["total"], 1) if row["total"] else None
    return {"total": row["total"], "present": row["present"], "pct": pct}


# -------------------------------------------------------------------- auth
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = get_db().execute("SELECT * FROM users WHERE username = ?",
                                (request.form.get("username", "").strip(),)).fetchone()
        if user and check_password_hash(user["password_hash"], request.form.get("password", "")):
            session.clear()
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            nxt = request.args.get("next")
            return redirect(nxt if nxt and nxt.startswith("/") else url_for("dashboard"))
        flash("Wrong username or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# --------------------------------------------------------------- dashboard
@app.route("/")
@login_required
def dashboard():
    db = get_db()
    today = date.today().isoformat()
    stats = {
        "students": db.execute("SELECT COUNT(*) FROM students").fetchone()[0],
        "courses": db.execute("SELECT COUNT(*) FROM courses").fetchone()[0],
        "present_today": db.execute(
            "SELECT COUNT(*) FROM attendance WHERE day = ? AND status = 'present'", (today,)).fetchone()[0],
        "marked_today": db.execute("SELECT COUNT(*) FROM attendance WHERE day = ?", (today,)).fetchone()[0],
    }
    overall = db.execute(
        "SELECT COUNT(*) AS t, COALESCE(SUM(status = 'present'), 0) AS p FROM attendance").fetchone()
    stats["overall_pct"] = round(overall["p"] * 100 / overall["t"]) if overall["t"] else None
    by_course = db.execute(
        "SELECT c.code, c.name, COUNT(s.id) AS n FROM courses c "
        "LEFT JOIN students s ON s.course_id = c.id GROUP BY c.id ORDER BY n DESC").fetchall()
    top = max([r["n"] for r in by_course], default=0) or 1
    recent = db.execute(
        "SELECT s.*, c.code AS course_code FROM students s LEFT JOIN courses c ON c.id = s.course_id "
        "ORDER BY s.id DESC LIMIT 5").fetchall()
    return render_template("dashboard.html", stats=stats, by_course=by_course, top=top, recent=recent)


# ---------------------------------------------------------------- students
def query_students(q, course_id):
    sql = ("SELECT s.*, c.code AS course_code, c.name AS course_name FROM students s "
           "LEFT JOIN courses c ON c.id = s.course_id WHERE 1=1")
    params = []
    if q:
        sql += " AND (s.name LIKE ? OR s.roll_no LIKE ? OR s.email LIKE ?)"
        params += [f"%{q}%"] * 3
    if course_id:
        sql += " AND s.course_id = ?"
        params.append(course_id)
    return get_db().execute(sql + " ORDER BY s.roll_no", params).fetchall()


@app.route("/students")
@login_required
def students():
    q = request.args.get("q", "").strip()
    course_id = request.args.get("course_id", "")
    rows = query_students(q, course_id)
    courses = get_db().execute("SELECT * FROM courses ORDER BY name").fetchall()
    return render_template("students.html", students=rows, courses=courses, q=q, course_id=course_id)


@app.route("/students/export")
@login_required
def export_students():
    rows = query_students(request.args.get("q", "").strip(), request.args.get("course_id", ""))
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["Roll No", "Name", "Email", "Phone", "DOB", "Gender", "Course", "Address", "Joined"])
    for s in rows:
        w.writerow([s["roll_no"], s["name"], s["email"], s["phone"], s["dob"], s["gender"],
                    s["course_name"], s["address"], s["joined_on"]])
    return Response(out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=students.csv"})


@app.route("/students/add", methods=["GET", "POST"])
@login_required
def add_student():
    db = get_db()
    courses = db.execute("SELECT * FROM courses ORDER BY name").fetchall()
    data = student_form_data() if request.method == "POST" else {}
    if request.method == "POST":
        if not data["roll_no"] or not data["name"]:
            flash("Roll number and name are required.", "error")
        else:
            try:
                db.execute(
                    "INSERT INTO students (roll_no, name, email, phone, dob, gender, address, course_id, joined_on) "
                    "VALUES (:roll_no, :name, :email, :phone, :dob, :gender, :address, :course_id, :joined)",
                    {**data, "joined": date.today().isoformat()})
                db.commit()
                flash(f"{data['name']} was added.", "success")
                return redirect(url_for("students"))
            except sqlite3.IntegrityError:
                flash(f"Roll number {data['roll_no']} already exists.", "error")
    return render_template("student_form.html", student=data, courses=courses, editing=False)


@app.route("/students/<int:sid>/edit", methods=["GET", "POST"])
@login_required
def edit_student(sid):
    db = get_db()
    student = db.execute("SELECT * FROM students WHERE id = ?", (sid,)).fetchone()
    if not student:
        flash("Student not found.", "error")
        return redirect(url_for("students"))
    courses = db.execute("SELECT * FROM courses ORDER BY name").fetchall()
    if request.method == "POST":
        data = student_form_data()
        if not data["roll_no"] or not data["name"]:
            flash("Roll number and name are required.", "error")
        else:
            try:
                db.execute(
                    "UPDATE students SET roll_no=:roll_no, name=:name, email=:email, phone=:phone, dob=:dob, "
                    "gender=:gender, address=:address, course_id=:course_id WHERE id=:id", {**data, "id": sid})
                db.commit()
                flash("Student details updated.", "success")
                return redirect(url_for("student_detail", sid=sid))
            except sqlite3.IntegrityError:
                flash(f"Roll number {data['roll_no']} already exists.", "error")
        student = {**data, "id": sid}
    return render_template("student_form.html", student=student, courses=courses, editing=True)


@app.route("/students/<int:sid>")
@login_required
def student_detail(sid):
    db = get_db()
    student = db.execute(
        "SELECT s.*, c.code AS course_code, c.name AS course_name FROM students s "
        "LEFT JOIN courses c ON c.id = s.course_id WHERE s.id = ?", (sid,)).fetchone()
    if not student:
        flash("Student not found.", "error")
        return redirect(url_for("students"))
    marks = db.execute("SELECT * FROM marks WHERE student_id = ? ORDER BY id DESC", (sid,)).fetchall()
    avg = None
    if marks:
        avg = round(sum(m["score"] * 100 / m["max_score"] for m in marks) / len(marks), 1)
    recent_att = db.execute("SELECT * FROM attendance WHERE student_id = ? ORDER BY day DESC LIMIT 10",
                            (sid,)).fetchall()
    return render_template("student_detail.html", student=student, marks=marks, avg=avg,
                           att=attendance_summary(db, sid), recent_att=recent_att)


@app.route("/students/<int:sid>/delete", methods=["POST"])
@login_required
def delete_student(sid):
    db = get_db()
    db.execute("DELETE FROM students WHERE id = ?", (sid,))
    db.commit()
    flash("Student deleted.", "success")
    return redirect(url_for("students"))


# ----------------------------------------------------------------- courses
@app.route("/courses", methods=["GET", "POST"])
@login_required
def courses():
    db = get_db()
    if request.method == "POST":
        code = request.form.get("code", "").strip().upper()
        name = request.form.get("name", "").strip()
        credits = request.form.get("credits", "3")
        if not code or not name:
            flash("Course code and name are required.", "error")
        else:
            try:
                db.execute("INSERT INTO courses (code, name, credits) VALUES (?, ?, ?)",
                           (code, name, int(credits) if credits.isdigit() else 3))
                db.commit()
                flash(f"Course {code} added.", "success")
            except sqlite3.IntegrityError:
                flash(f"Course code {code} already exists.", "error")
        return redirect(url_for("courses"))
    rows = db.execute(
        "SELECT c.*, COUNT(s.id) AS n FROM courses c LEFT JOIN students s ON s.course_id = c.id "
        "GROUP BY c.id ORDER BY c.code").fetchall()
    return render_template("courses.html", courses=rows)


@app.route("/courses/<int:cid>/delete", methods=["POST"])
@login_required
def delete_course(cid):
    db = get_db()
    db.execute("DELETE FROM courses WHERE id = ?", (cid,))
    db.commit()
    flash("Course deleted. Its students are now unassigned.", "success")
    return redirect(url_for("courses"))


# -------------------------------------------------------------- attendance
@app.route("/attendance", methods=["GET", "POST"])
@login_required
def attendance():
    db = get_db()
    courses_list = db.execute("SELECT * FROM courses ORDER BY name").fetchall()
    course_id = request.values.get("course_id", "")
    day = request.values.get("day") or date.today().isoformat()
    roster = []
    if course_id:
        roster = db.execute(
            "SELECT s.id, s.roll_no, s.name, a.status FROM students s "
            "LEFT JOIN attendance a ON a.student_id = s.id AND a.day = ? "
            "WHERE s.course_id = ? ORDER BY s.roll_no", (day, course_id)).fetchall()
        if request.method == "POST":
            for s in roster:
                status = request.form.get(f"status_{s['id']}", "absent")
                db.execute(
                    "INSERT INTO attendance (student_id, day, status) VALUES (?, ?, ?) "
                    "ON CONFLICT(student_id, day) DO UPDATE SET status = excluded.status",
                    (s["id"], day, status))
            db.commit()
            flash(f"Attendance saved for {day}.", "success")
            return redirect(url_for("attendance", course_id=course_id, day=day))
    return render_template("attendance.html", courses=courses_list, course_id=course_id, day=day, roster=roster)


# ------------------------------------------------------------------- marks
@app.route("/marks", methods=["GET", "POST"])
@login_required
def marks():
    db = get_db()
    if request.method == "POST":
        try:
            score = float(request.form["score"])
            max_score = float(request.form.get("max_score") or 100)
            if max_score <= 0 or score < 0 or score > max_score:
                raise ValueError
            subject = request.form.get("subject", "").strip()
            exam = request.form.get("exam", "").strip()
            if not subject or not exam or not request.form.get("student_id"):
                raise ValueError
            db.execute("INSERT INTO marks (student_id, subject, exam, score, max_score) VALUES (?, ?, ?, ?, ?)",
                       (request.form["student_id"], subject, exam, score, max_score))
            db.commit()
            flash("Marks saved.", "success")
        except (ValueError, KeyError):
            flash("Fill every field. Score must be between 0 and the maximum.", "error")
        return redirect(url_for("marks", course_id=request.args.get("course_id", "")))
    course_id = request.args.get("course_id", "")
    sql = ("SELECT m.*, s.name, s.roll_no FROM marks m JOIN students s ON s.id = m.student_id")
    params = []
    if course_id:
        sql += " WHERE s.course_id = ?"
        params.append(course_id)
    rows = db.execute(sql + " ORDER BY m.id DESC", params).fetchall()
    courses_list = db.execute("SELECT * FROM courses ORDER BY name").fetchall()
    student_list = db.execute("SELECT id, roll_no, name FROM students ORDER BY roll_no").fetchall()
    return render_template("marks.html", marks=rows, courses=courses_list, students=student_list,
                           course_id=course_id)


@app.route("/marks/<int:mid>/delete", methods=["POST"])
@login_required
def delete_mark(mid):
    db = get_db()
    db.execute("DELETE FROM marks WHERE id = ?", (mid,))
    db.commit()
    flash("Marks entry deleted.", "success")
    return redirect(url_for("marks"))


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
